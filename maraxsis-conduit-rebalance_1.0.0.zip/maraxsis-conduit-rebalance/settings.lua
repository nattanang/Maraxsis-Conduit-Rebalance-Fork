data:extend({
	{
		type = "bool-setting",
		name = "conduit-rebalance-mk3-atmosphere",
		setting_type = "startup",
		default_value = true,
	},
})
